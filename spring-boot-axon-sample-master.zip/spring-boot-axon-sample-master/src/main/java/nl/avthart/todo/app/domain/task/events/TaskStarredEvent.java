package nl.avthart.todo.app.domain.task.events;

import lombok.Value;

/**
 * @author albert
 */
@Value
public class TaskStarredEvent implements TaskEvent {

	private  String id;

	@Override
	public String getId() {
		// TODO Auto-generated method stub
		return id;
	}

	public TaskStarredEvent(String id) {
		super();
		this.id = id;
	}
	
	
	
}
