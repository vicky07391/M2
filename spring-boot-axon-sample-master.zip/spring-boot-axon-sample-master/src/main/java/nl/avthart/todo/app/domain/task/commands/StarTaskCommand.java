package nl.avthart.todo.app.domain.task.commands;

import lombok.Value;

import org.axonframework.commandhandling.annotation.TargetAggregateIdentifier;

/**
 * @author albert
 */
@Value
public class StarTaskCommand {

	@TargetAggregateIdentifier
	private  String id;

	public String getId() {
		return id;
	}

	public StarTaskCommand(String id) {
		super();
		this.id = id;
	}
	
	
}
