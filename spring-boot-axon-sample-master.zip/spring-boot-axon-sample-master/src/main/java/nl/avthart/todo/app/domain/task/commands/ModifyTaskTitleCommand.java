package nl.avthart.todo.app.domain.task.commands;

import javax.validation.constraints.NotNull;

import lombok.Value;

import org.axonframework.commandhandling.annotation.TargetAggregateIdentifier;

/**
 * @author albert
 */
@Value
public class ModifyTaskTitleCommand {

	@TargetAggregateIdentifier
	private  String id;

	@NotNull
	private  String title;

	public String getId() {
		return id;
	}

	public String getTitle() {
		return title;
	}

	public ModifyTaskTitleCommand(String id, String title) {
		super();
		this.id = id;
		this.title = title;
	}
	
	
	
}

