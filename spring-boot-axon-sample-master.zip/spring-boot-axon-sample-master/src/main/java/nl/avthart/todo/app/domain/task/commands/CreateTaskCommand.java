package nl.avthart.todo.app.domain.task.commands;

import javax.validation.constraints.NotNull;

import lombok.Value;

/**
 * @author albert
 */
@Value
public class CreateTaskCommand {

	@NotNull
	private  String id;
	
	private  String username;
	
	private  String title;

	public String getId() {
		return id;
	}

	public String getUsername() {
		return username;
	}

	public String getTitle() {
		return title;
	}

	public CreateTaskCommand(String id, String username, String title) {
		super();
		this.id = id;
		this.username = username;
		this.title = title;
	}

    
}
