package nl.avthart.todo.app.domain.task.events;

public interface TaskEvent {

	public String getId();
	
}
