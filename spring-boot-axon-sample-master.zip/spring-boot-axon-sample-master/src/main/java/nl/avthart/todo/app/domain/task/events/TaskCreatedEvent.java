package nl.avthart.todo.app.domain.task.events;

import lombok.Value;

/**
 * @author albert
 */
@Value
public class TaskCreatedEvent implements TaskEvent {

	private  String id;
	
	private  String username;
	
	private  String title;
	

	public TaskCreatedEvent(String id, String username, String title) {
		super();
		this.id = id;
		this.username = username;
		this.title = title;
	}

	public String getId() {
		return id;
	}

	public String getUsername() {
		return username;
	}

	public String getTitle() {
		return title;
	}

	
	
/*	@Override
	public String getId() {
		// TODO Auto-generated method stub
		return null;
	}*/

	
}
