package nl.avthart.todo.app.domain.task.events;

import lombok.Value;

/**
 * @author albert
 */
@Value
public class TaskCompletedEvent implements TaskEvent {

	private  String id;

	@Override
	public String getId() {
		// TODO Auto-generated method stub
		return id;
	}

	public TaskCompletedEvent(String id) {
		super();
		this.id = id;
	}
	
	
	
}
