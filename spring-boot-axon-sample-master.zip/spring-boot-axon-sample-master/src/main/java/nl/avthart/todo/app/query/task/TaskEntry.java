package nl.avthart.todo.app.query.task;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;

/**
 * @author albert
 */
@Document(indexName = "tasks", type = "entry")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@ToString
@EqualsAndHashCode
public class TaskEntry {

	@Id
	private String id;
	
	private String username;
	
	
	private String title;
	
	
	private boolean completed;
	
	
	private boolean starred;

	public String getUsername() {
		return username;
	}

	public TaskEntry(String id, String username, String title, boolean completed, boolean starred) {
		super();
		this.id = id;
		this.username = username;
		this.title = title;
		this.completed = completed;
		this.starred = starred;
	}

	public void setCompleted(boolean completed) {
		this.completed = completed;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setStarred(boolean starred) {
		this.starred = starred;
	}

    
	
}

