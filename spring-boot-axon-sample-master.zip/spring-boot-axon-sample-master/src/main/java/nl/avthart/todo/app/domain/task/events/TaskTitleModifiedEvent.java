package nl.avthart.todo.app.domain.task.events;

import lombok.Value;

/**
 * @author albert
 */
@Value
public class TaskTitleModifiedEvent implements TaskEvent {

	private  String id;
	
	private  String title;

	@Override
	public String getId() {
		// TODO Auto-generated method stub
		return id;
	}

	public TaskTitleModifiedEvent(String id, String title) {
		super();
		this.id = id;
		this.title = title;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	
	
}
