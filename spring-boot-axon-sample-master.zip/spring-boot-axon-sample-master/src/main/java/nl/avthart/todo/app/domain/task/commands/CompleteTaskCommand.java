package nl.avthart.todo.app.domain.task.commands;

import lombok.Value;

import org.axonframework.commandhandling.annotation.TargetAggregateIdentifier;

/**
 * @author albert
 */
@Value
public class CompleteTaskCommand {

	@TargetAggregateIdentifier
	private  String id;

	public String getId() {
		return id;
	}

	public CompleteTaskCommand(String id) {
		super();
		this.id = id;
	}
	
	
	
}